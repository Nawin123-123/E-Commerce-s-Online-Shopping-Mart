export default function Loader() {
  return (
    <div className="flex justify-center items-center py-20">
      <div className="animate-spin rounded-full h-12 w-12 border-4 border-cta border-t-transparent" />
    </div>
  );
}
